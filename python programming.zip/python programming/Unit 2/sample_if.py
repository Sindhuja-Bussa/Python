#if Condition
a=int(input("Enter Value for a:"))
if a == 10:
    print(a)

#Shortend if
b=int(input("Enter Value for b:"))
if b==10: print(b)
