#elif conditional Statement

#greatest of 3 numbers

'''a=int(input("enter value for a:"))
b=int(input("enter value for b:"))
c=int(input("enter value for c:"))
if a>b and a>c:
    print("a is greater")
elif b>c and b>a:
    print("b is greater")
else:
    print("c is greater")'''
    
#Checking a number is positive,negative or zero
a = int(input("enter the number:"))
if a>0:
    print("Positive Number")
elif a<0:
    print("Negative Number")
else:
    print("Zero")
