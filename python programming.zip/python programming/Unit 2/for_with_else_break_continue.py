#Looping Statements - for,for with else, for - break,continue
'''syntax:
for <control-variable> in <sequence/range>
     body of the loop'''
#Example:1
'''list1 = {1,2,3,4,5}
for x in list1:
    print(x)
#Example:2
for y in "S R University":
    print(y,end=" ")
#for y in "S R University":
    #print(y)
#range : range([start],[end],[step])
for x in range(10):
    print(i)
#Example:3
n=int(input("enter value for n:"))
for x in range(1,n+1):
    print(x)
#Example:4
n=int(input("enter value for n:"))
s=0
for x in range(1,n+1):
    s=s+x
print("sum:",s)
#Example:5
n=int(input("enter value for n:"))
fact=1
for x in range(1,n+1):
    fact=fact*x
print("factorial:",fact)'''
#Example:6
start=int(input("enter the starting value:"))
end=int(input("enter the ending value:"))
for x in range(start,end+1):
    p=len(str(x))
    s=0
    t=x
    while t>0:
        rem=t%10
        s=s+rem**p
        t=t//10
    if x==s:
        print(x)



       



     
