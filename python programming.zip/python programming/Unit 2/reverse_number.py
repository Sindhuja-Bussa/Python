# Write a Python program to print the reverse of a given number

n=int(input("enter value for n:"))
rev=0
while n>0:
         x=n%10
         rev=rev*10+x
         n=n//10
print("reversed number:",rev)
