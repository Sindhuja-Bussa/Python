n=int(input("enter value for n:"))
a=()
print("enter tuple elements:")
x=list(a)
for i in range(n):
    x.append(int(input()))
print(x)
t=tuple(x)
print("Press 1 for min element")
print("Press 2 for max element")
print("Press 3 for avg element")
print("Press 4 for sort in ascending")
print("Press 5 for sort in descending")
print("Press 6 for exit")
while (input("do you really want to continue[y/n]:")== 'y'):       
    choice=-1
    choice=int(input("enter your choice:"))    
    if choice==1:        
        print(min(t))
    elif choice==2:
        print(max(t))
    elif choice==3:
        print(sum(t)/len(t))
    elif choice==4:
        x.sort()
        y=tuple(x)
        print(y)
    elif choice==5:
        x.sort(reverse=True)
        y=tuple(x)
        print(y)
    elif choice==6:
        exit()
    else:
        print("enter correct choice")
else:
    quit()
