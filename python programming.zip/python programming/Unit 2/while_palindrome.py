# Write a Python program to check whether the given number is palindrome or not

n=int(input("enter value for n:"))
rev=0
m=n
while n>0:
         x=n%10
         rev=rev*10+x
         n=n//10

if m==rev:

    print("Palindrome")

else:
    print("not a Palindrome")
             
