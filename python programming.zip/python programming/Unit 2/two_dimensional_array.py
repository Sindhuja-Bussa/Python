#Example:1 Two dimensional array(Print Matrix)

m=int(input("enter no.of rows:"))
n=int(input("enter no.of columns:"))
x=[]
print("enter array elements:")
for i in range(m):
    a = []
    for j in range(n):
        a.append(int(input()))
    x.append(a)
print("the Matrix A is:")
for i in range(m):
    for j in range(n):
        print(x[i][j],end=" ")
    print()

#Example:2 Two dimensional array(Transpose of a Matrix)

m=int(input("enter no.of rows:"))
n=int(input("enter no.of columns:"))
x=[]
print("enter array elements:")
for i in range(m):
    a = []
    for j in range(n):
        a.append(int(input()))
    x.append(a)
print("the Transpose of a Matrix A is:")
for i in range(m):
    for j in range(n):
        print(x[j][i],end=" ")
    print()
#Example:3 Two dimensional array(Lower Traingular Matrix)

m=int(input("enter no.of rows:"))
n=int(input("enter no.of columns:"))
x=[]
print("enter array elements:")
for i in range(m):
    a = []
    for j in range(n):
        a.append(int(input()))
    x.append(a)
print("the Lower Traingular Matrix A is:")
for i in range(m):
    for j in range(n):
        if i>=j:
           print(x[i][j],end=" ")
    print()

#Example:4 Two dimensional array(Upper Traingular Matrix)

m=int(input("enter no.of rows:"))
n=int(input("enter no.of columns:"))
x=[]
print("enter array elements:")
for i in range(m):
    a = []
    for j in range(n):
        a.append(int(input()))
    x.append(a)
print("the Upper Traingular Matrix A is:")
for i in range(m):
    for j in range(n):
        if i<=j:
           print(x[i][j],end=" ")		 
    print()
#Example 5: for with else
n = int(input("enter value for n:"))
for i in range(n):
    print(i)
else:
    print("END 0F THE LOOP")

#Example 6: for with break
n = int(input("enter value for n:"))
for i in range(n):
    if i==5:
        break
    print(i)
    
#Example 7: for with continue
n = int(input("enter value for n:"))
for i in range(n):
    if i==5:
       continue
    print(i)





    
    
