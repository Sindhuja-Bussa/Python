#if..else Condition

#Greatest of 3 numbers
a=int(input("enter value for a:"))
b=int(input("enter value for b:"))
if a>b:
    print("a is greater")
else:
    print("b is greater")

#Shortend for if..else
    
a=int(input("enter value for a:"))
b=int(input("enter value for b:"))
print("a is greater") if a>b else print("b is greater")

#Check Whether the number is even or odd

a=int(input("enter value for a:"))
if a%2==0:
    print("a is even")
else:
    print("a is odd")
