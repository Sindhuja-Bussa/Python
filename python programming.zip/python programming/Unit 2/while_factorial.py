#Write a Python program to print factorial of a number

i=1
fact=1
n = int(input("enter value for n:"))
while i<=n:
    fact = fact*i
    i+=1
print("factorial:",fact)
