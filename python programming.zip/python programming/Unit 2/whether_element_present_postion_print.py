n = int(input("enter value for n:"))
a = []
print("enter elements:")
for i in range(n):
    a.append(int(input()))
print(a)
position = -1
search = int(input("enter an element to be search:"))
for i in range(n):
    if a[i] == search:
        position = i+1
if position == -1:
    print("element is not found")
else:
    print("Element",search,"found at position",position)
