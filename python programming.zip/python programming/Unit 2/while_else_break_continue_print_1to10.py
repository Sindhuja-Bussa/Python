#Printing 1 to 10 numbers

#while with else

print("while with else")
i=1
n = int(input("enter value for n:"))
while i<=n:
       print(i)
       i+=1
else:
      print("enter correct number / End of the loop")

#while with break

print("while with break")      
i=1
n = int(input("enter value for n:"))
while i<=n:
       print(i)
       i+=1
       if i==5:
          break

#while with continue
        
print("while with continue")
i=0
n = int(input("enter value for n:"))
while i<n:
    
    i+=1
    if i==5:
        continue
    print(i)
    
