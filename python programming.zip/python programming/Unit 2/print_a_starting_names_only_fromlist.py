n=int(input("enter value for n:"))
a=[]
print("enter the strings:")
for i in range(n):
    a.append(input())
print(a)
for j in a:
    if j[0] == 'a' or j[0] == 'A':
        print(j)
