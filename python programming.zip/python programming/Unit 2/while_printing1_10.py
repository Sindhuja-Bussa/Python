# Write a Python program to print 1 to 10 numbers

#1. While Loop

n=int(input("enter value for n:"))
i=1
while i<=n:
      print(i,end=" ")
      i+=1
     #print(i) vertical



             
