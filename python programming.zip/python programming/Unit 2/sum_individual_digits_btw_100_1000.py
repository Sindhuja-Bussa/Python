# Write a Python program to find the sum of individual digits

n=int(input("enter value for n between 100 to 1000:"))
s=0
if n>=100 and n<=1000:
    while n>0:
         x=n%10
         s=s+x
         n=n//10
    print("sum of individual digits:",s)
else:
    print("enter the number in given range")

