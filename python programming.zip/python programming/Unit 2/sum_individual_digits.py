# Write a Python program to find the sum of individual digits

n=int(input("enter value for n:"))
s=0
while n>0:
         x=n%10
         s=s+x
         n=n//10
print("sum of individual digits:",s)
