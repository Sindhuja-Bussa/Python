#Actual Arguments VS Formal Frguments:

'''def add(x,y): #(x,y) are formal arguments
    print("addition:",x+y)
add(2,3) # (2,3) are actual arguments

#Return Statement:

def mul(x,y):
    return x*y
a=int(input("enter value for a:"))
b=int(input("enter value for b:"))
z=mul(a,b)
print("multiplication:",z)

#Pass Statement:

def sub(x,y):
    pass
sub(3,2)

#Recursion:

#Factorial

def fact(x):
    if(x==1):
        return 1;
    else:
        return(x*fact(x-1))
x=int(input("enter value for x:"))
z=fact(x)
print("factorial:",z)       

#Greatest Common Divisor

def gcd(x,y):
    if y==0:
        return x
    else:
        return gcd(y,x%y)
x=int(input("enter value for x:"))
y=int(input("enter value for y:"))
z=gcd(x,y)
print("greatest common divisor:",z)

#Fibbonacci Series

def fib(x):
    if x==0 or x==1:
        return x
    else:
        return(fib(x-1)+fib(x-2))
i=0
x=int(input("enter value for x:"))
for i in range(x):
    
    print(fib(i),end=" ")

# Pass Statement:
function definitions cannot be empty,
but if you for some reason have a function definition with no content,
put in the pass statement to avoid getting an error
#Example:
def sub(x,y):
    pass
sub(30,20)'''

#Lamda Function

#Multiple arguments 

z = lambda a,b,c : a*b+c
print("lambda:",z(2,3,5))

#lambda functions

def myfun(x):
    return lambda a:a*x
mydoubler = myfun(2)
mytrippler = myfun(3)
print(mydoubler(10))
print(mytrippler(10))













    






















