#Menu driven program to do various list operations
'''1. Insert an element
2. Insert an element desired position
3. Update an element
4. Delete an element
5. Delete element desired position
6. Display
7.Exit'''

n = int(input("enter value for n:"))
a = []
print("enter elements:")
for i in range(n):
    a.append(int(input()))
print(a)
print("1.Insert an element")
print("2.Insert an element desired position")
print("3.Update an element")
print("4.Delete an element")
print("5.Delete element desired position")
print("6.Display")
print("7.Exit")
while (input("do you really want to continue[y/n]:")== 'y'):
    choice = -1
    choice = int(input("enter your choice:"))
    if choice == 1:
        e = int(input("enter element to be inserted:"))
        a.append(e)
        print(a)
    elif choice == 2:
        i = int(input("enter the position:"))
        e = int(input("enter element to be inserted:"))
        a.insert(i,e)
        print(a)   
    elif choice == 3:
        i = int(input("enter the position:"))
        e = int(input("enter element to be updated:"))
        a[i] = e
        print(a) 
    elif choice == 4:
        e = int(input("enter element to be deleted:"))
        a.remove(e)
        print(a)
    elif choice == 5:
        i = int(input("enter the position:"))
        a.pop(i)
        print(a) 
    elif choice == 6:
        print(a) 
    elif choice == 7:
        exit()
    else:
        print("enter correct choice")
else:
    quit()
