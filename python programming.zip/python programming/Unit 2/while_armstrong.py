# Write a Python program to check whether the given number is armstrong or not

n=int(input("enter value for n:"))
s=0
m=n
while n>0:
         x=n%10
         s=s+x*x*x
         n=n//10

if m==s:

    print("Armstrong")

else:
    print("not an Armstrong")
             

