#Functions
#Types of Functions: 1.Built-in functions 2.User defined functions(def)
#Example 1:

'''def world():
    print("Hello World")
    print("Welcome to SR University")   
world()#function calling

def sum():
    x=int(input("enter value for x:"))
    y=int(input("enter value for y:"))
    c=x+y
    print("sum:",c)
sum()

#function arguments
1.Required arguments/No.of arguments
2.Default arguments
3.Keyword arguments
4.Orbitary arguments

#1.Required arguments/No.of arguments:

#Example 1:
def add(x,y):
    print("addition:",x+y)
add(10,20) 

#2.Default arguments:

def my_country(country="India"):
    print("I Belongs to "+country)
my_country()
my_country("USA")
my_country("Russia")
my_country()

def my_college(college="S R University"):
    print("I Belongs to "+college)
my_college()
my_college("SRIT")
my_college("SRIIT")
my_college()

#3.Keyword arguments: KEYS=VALUES

def my_branch(branch1,branch2,branch3):
    print("My Branch is "+branch3)
my_branch(branch1="CS & AI",branch2="CSDS",branch3="CSE")

def greater(a,b,c):
    if a>b and a>c:
        print(a)
    elif b>c:
        print(b)
    else:
        print(c)
        
greater(a=10,b=20,c=30)
'''
#4.i)Orbitary arguments: *args it works only on strings

def my_course(*c):
    print(c[0])
    print(c[1])
    
my_course("CSE","ECE","EEE")

#ii)Orbitary Keyword arguments: **kwargs

def my_name(**name):
    print(name["first"])
my_name(first="Sindhuja",last="Bussa")

#Print factorial of a number

'''def fact():
    i=1
    factorial=1
    x=int(input("enter value for x:"))
    while i<=x:
        factorial=factorial*i
        i+=1
    print("factorial:",factorial)

fact()

def fact(x,y):
    i=1
    for i in range(1,x+1):
        y=y*i
    print(y)    
x=int(input("enter value for x:"))
f=1
fact(x,f)'''
        
#Print Armstrong Numbers within the range
def arm():
    start = int(input("enter starting value:"))
    end = int(input("enter ending value:"))
    for n in range(start,end+1):
        p = len(str(n))
        s = 0
        t = n
        while t>0:
            rem = t%10
            s = s+rem**p
            t = t//10
        if n==s:
            print(n)
arm()




    
    
