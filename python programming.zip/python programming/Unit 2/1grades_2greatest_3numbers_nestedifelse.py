#Nested if Condition

#Grades of a Student
m1 = int(input("enter first subject marks:"))
m2 = int(input("enter second subject marks:"))
m3 = int(input("enter third subject marks:"))

avg = (m1+m2+m3)//3
if avg<=100:
    if avg>=91:
        print("A+ Grade")
    elif avg>=81: 
        print("A Grade")
    elif avg>=71:
        print("B Grade")
    elif avg>=61:
        print("C Grade")
    elif avg>=51:
        print("D Grade")
    elif avg>=41:
        print("E Grade")
    else:
        print("Fail")
else:
    print("each subject limit is 100")


#Greatest of 3 numbers

'''a=int(input("enter value for a:"))
b=int(input("enter value for b:"))
c=int(input("enter value for c:"))
if a>b:
    if a>c:
      print("a is greater")
    else:
      print("c is greater")
elif b>a:
    if b>c:
      print("b is greater")
    else:
      print("c is greater")
else:
    print("c is greater")'''

    






































    











    
































































