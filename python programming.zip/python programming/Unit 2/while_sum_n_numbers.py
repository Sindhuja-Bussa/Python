# Write a Python program to find sum of n natural numbers

n=int(input("enter value for n:"))
i=1
s=0
while i<=n:
             s = s+i
             i+=1
print("sum of n natural numbers:",s)
