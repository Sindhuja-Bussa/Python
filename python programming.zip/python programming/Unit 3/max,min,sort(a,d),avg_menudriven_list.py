n=int(input("enter value for n:"))
a=[]
print("enter elements:")
for i in range(n):
    a.append(int(input()))
print(a)
print("Press 1 for min element")
print("Press 2 for max element")
print("Press 3 for avg element")
print("Press 4 for sort in ascending")
print("Press 5 for sort in descending")
print("Press 6 for exit")
while (input("do you really want to continue:")== 'y'):       
    choice=-1
    choice=int(input("enter your choice:"))    
    if choice==1:        
        print(min(a))
    elif choice==2:
        print(max(a))
    elif choice==3:
        print(sum(a)/len(a))
    elif choice==4:
        a.sort()
        print(a)
    elif choice==5:
        a.sort(reverse=True)
        print(a)
    elif choice==6:
        exit()
    else:
        print("enter correct choice:")
else:
    quit()
    
