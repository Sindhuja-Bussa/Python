'''s={}
s1=set()
print(s)
print(s1)
s={1,'a',"hello",2.5}
#unordered
print(s)#it will not print in order
#unindexed
#print(s[1]) it doesn't have an index values
#unchangable
s1[c]='a'
print(s)
#does not allow duplicate values
s1={1,2,1,4,2}
print(s1)'''

#WAP to access the sets and to implement set functions.
#Accesing sets:
'''s={1,'a',"hello",2.5}
for i in s:
    print(i)
#type
print(type(s))
#set functions
print("set functions")
#adding an element:add()-single elements
s.add(10)
print(s)
#adding multiple elements-update()
a={1,2,'a','b',2.5}
b={1,2,3}
a.update(b)
print(a)
a.update([10,20,30])
print(a)
#delete:remove(),discard(),and pop()
#remove()
a={1,2,'a','b',2.5}
a.remove(2.5)
print(a)
#discard()
a.discard('a')
print(a)
#pop()
x=a.pop()
print(x)
print(a)
#delete entire set:clear(),del keyword
#clear()
s2={1,2,3}
s3={5,6,7,8}
s2.clear()
print(s2)
#del keyword
print(s3)
del s3
#print(s3)'''
#WAP to implement union,intersection,difference,symmetric_difference
'''#union : |,union(),update()
print("union of two sets")
a={1,2,3,4,5}
b={4,5,6,7,8}
#|
print(a|b)
#union()
print(a.union(b))
#update()
a.update(b)
print(a)
b.update(a)
print(b)

#intersection:&,intersection(),intersection_update()
a={1,2,3,4,5}
b={4,5,6,7,8}
#&
print("intersection of two sets")
print(a&b)
#intersection()
print(a.intersection(b))
print(b.intersection(a))
#intersection_update()
a.intersection_update(b)
print(a)
b.intersection_update(a)
print(b)
#difference:-,difference(),difference_update()
a={1,2,3,4,5}
b={4,5,6,7,8}
#-
print("difference of two sets")
print(a-b)
#difference()
print(a.difference(b))
print(b.difference(a))
#difference_update()
a.difference_update(b)
print(a)
b.difference_update(a)
print(b)
#symmetric difference:^,symmetric_difference(),symmetric_difference_update()
a={1,2,3,4,5}
b={4,5,6,7,8}
#^
print("symmetric_difference of two sets")
print(a^b)
#symmetric_difference()
print(a.symmetric_difference(b))
print(b.symmetric_difference(a))
#symmetric_difference_update()
a.symmetric_difference_update(b)
print(a)'''
#min(),max(),sum(),len(),average,sorted()

'''a={1,2,3,4,5}
print(min(a))
print(max(a))
print(sum(a))
print(len(a))
print("Average:",sum(a)/len(a))
print(sorted(a))#ascending order
'''
#Write a menu driven program
'''press 1.union
press 2.intersection
press 3.difference
press 4.symmetric difference
press 5.minimum element
press 6.maximum element
press 7.sum
press 8.average
press 9.sort in ascending
press 10.exit'''


n=int(input("enter value for n:"))
a={}
print("enter set elements:")
x=list(a)
for i in range(n):
    x.append(int(input()))
print(x)
s1=set(x)
n=int(input("enter value for n:"))
b={}
print("enter set elements:")
z=list(b)
for i in range(n):
    z.append(int(input()))
print(z)
s2=set(z)
print("press 1.union")
print("press 2.intersection")
print("press 3.difference")
print("press 4.symmetric difference")
print("press 5.minimum element")
print("press 6.maximum element")
print("press 7.sum")
print("press 8.average")
print("press 9.sort in ascending of 1st set")
print("press 10.exit")
while(input("do you really want to continue[y/n]:")=='y'):
    choice=-1
    choice=int(input("enter your choice:"))
    if choice==1:
        print("Union:",s1|s2)
    elif choice==2:
        print("Intersection:",s1&s2)
    elif choice==3:
        print("difference(s1-s2):",s1-s2)
        print("difference(s2-s1):",s2-s1)
    elif choice==4:
        print("symmetric_difference(s1^s2):",s1^s2)
        print("symmetric_difference(s2^s1):",s2^s1)
    elif choice==5:
        print("minimum of s1:",min(s1))
        print("minimum of s2:",min(s2))
    elif choice==6:
        print("maximum of s1:",max(s1))
        print("maximum of s2:",max(s2))
    elif choice==7:
        print("sum of s1:",sum(s1))
        print("sum of s2:",sum(s2))
    elif choice==8:
        print("average of s1:",sum(s1)/len(s1))
        print("average of s2:",sum(s2)/len(s2))        
    elif choice==9:
        x.sort()
        y=set(x)
        print("ascending order:",y)
    elif choice==10:
        exit()
    else:
        print("enter correct choice")
else:
    quit()
        
    

'''
Program 1
1. add element
    2. delete element
    3. min element
    4.max
    5.sum
    6.average
    7. exit
n = int(input("Enter a number:"))
s = set()
print("Enter the elements:")
for i in range(n):
    s.add(int(input()))
print(s)
print("1. add element")
print("2. delete element")
print("3. min element")
print("4. max element")
print("5. sum of elements")
print("6. average")
print("7. exit")
while(input("do you really want to continue[y/n]:")=='y'):
    choice = -1
    choice = int(input("Enter Your Choice(1-7):"))
    if choice == 1:
        e = int(input("Enter an element to be added:"))
        s.add(e)
        print(s)
    elif choice == 2:
        e = int(input("Enter an element to be removed:"))
        s.remove(e) #s.discard(e) or s.pop()
        print(s)
    elif choice == 3:
        print("Minimum Element in set is:",min(s))
    elif choice == 4:
        print("Maximum Element in set is:",max(s))
    elif choice == 5:
        print("Sum of set Elements:",sum(s))
    elif choice == 6:
        print("Average of set Elements:",sum(s)/len(s))
    elif choice == 7:
        quit()
    else:
        print("Enter correct choice")
else:
    exit()'''


#PROGRAM 2 
#menu driven program
'''read s1 and s2 dymanically
press 1 union
press 2 intersection
press 3 difference
press 4 symmetric difference
press 5 exit'''
n1 = int(input("Enter a number:"))
s1 = set()
print("Enter the elements for set1:")
for i in range(n1):
    s1.add(int(input()))
print(s1)
n2 = int(input("Enter a number:"))
s2 = set()
print("Enter the elements for set2:")
for i in range(n2):
    s2.add(int(input()))
print(s2)
print("1. UNION")
print("2. INTERSECTION")
print("3. DIFFERENCE")
print("4. SYMMETRIC DIFFERENCE")
print("5. EXIT")
while(input("do you really want to continue[y/n]:")=='y'):
    choice = -1
    choice = int(input("Enter Your Choice(1-5):"))
    #UNION
    if choice == 1:
        print(s1|s2)
        print(s1.union(s2))
        s1.update(s2)
        print(s1)
    #INTERSECTION
    elif choice == 2:
        print(s1&s2)
        print(s1.intersection(s2))
        s1.intersection_update(s2)
        print(s1)
    #DIFFERENCE
    elif choice == 3:
        print(s1-s2)
        print(s1.difference(s2))
        s1.difference_update(s2)
        print(s1)
    #SYMMETRIC DIFFERENCE
    elif choice == 4:
        print(s1^s2)
        print(s1.symmetric_difference(s2))
        s1.symmetric_difference_update(s2)
        print(s1)
    #EXIT
    elif choice == 5:
        quit()
    else:
            print("Enter correct choice")
else:
    exit()

















