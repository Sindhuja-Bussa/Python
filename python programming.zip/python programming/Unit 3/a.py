'''#List
l1=['a',1,2,'b',5]
print(l1)

#Accessing

print(l1[3])
print(l1[2+1])
print(l1[3-1])

#Mutable

l1[3]='c'
print(l1)'''

#WAP to print List operations

#List Operations:
#1.Concatination

print("Concatination")
a=[1,2,3,6]
b=['a',1,5]
print(a+b)

#2.Repetition

print("Repetition")
l2=["sru","APTT"]
print(l2*4)

#3.Membership : in,not in

print("Membership")
l3=["sru","srit",1]
print("sru" in l3)
print("sru" not in l3)

#Slicing: variable_name[start:end:step]

print("Slicing")
l4=['a',1,3,'b',2.5]
print(l4[:])
print(l4[0:])
print(l4[:5])
print(l4[0:5])
print(l4[1:4])
print(l4[0:5:1])
print(l4[0:5:2])
print(l4[-4:-1])
print(l4[::-1])
print(l4[::-2])

#Max,min,sum,avg

print("Average")
l5=[1,2,4,5,6]
print(max(l5))
print(min(l5))
print(sum(l5))
#WAP to print list functions

#List Functions/Methods

#1.Length:len()

print("Length")
a=[1,2,3,'a','b']
print(len(a))

#2.Empty List:[]
print("Empty List")
b=[]
print(b)

#append()
print("append")
c=[3,4,5,6]
c.append(10)
print(c)
c.append([20,30,40])
print(c)

#insert():insert(index,value)

print("Insert")
d=[1,2,3,'a']
d.insert(2,10)
print(d)

#extend()

print("extend:")
e=[1,2,3]
f=[4,5,6]
e.extend(f)
print(e)

#count()

print("count")
g=[10,20,10,30,40]
print(g.count(10))
print(g.count(40))

#find: returns index()of first occurance of element

print("find")
print(g.index(10))

#remove():remove the given element from list

print("remove")
h=[2,3,5,1]
h.remove(5)
print(h)


#pop():pop(index)<removes the element passed with index value, if no index,removes last element

print("pop")
g=[10,20,10,30,40]
print(g.pop(0))
print(g)
print(g.pop())
print(g)

#reverse()

print("reverse")
i=[2,3,5,1]
i.reverse()
print(i)

#Wap to sort the lists
#sort
j=[1,2,3,4,5]
#ascending order
print("ascending order")
j.sort()
print(j)

#descending order
print("descending order")
j.sort(reverse=True)
print(j)

























