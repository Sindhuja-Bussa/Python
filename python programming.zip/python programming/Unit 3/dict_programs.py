#Write a program to count the number of items in a character appears in a given string.
'''str=input("enter the string:")
d=dict()
for ch in str:
    if ch in d:
        d[ch]=d[ch]+1
    else:
        d[ch]=1
for i in d:
    print(i,":",d[i])
#Write a program to convert number entered by the user into its corresponding number in words.  
#example: if the input is 876 then the output should be "Eight Seven Six"
n=input("enter a number:")
num_words={0:'Zero',
           1:'One',
           2:'Two',
           3:'Three',
           4:'Four',
           5:'Five',
           6:'Six',
           7:'Seven',
           8:'Eight',
           9:'Nine'
           }
r=''
for i in n:
    key=int(i)
    value=num_words[key]
    r=r+' '+value
print("entered number is:",n)
print("Word Conversion:",r)'''
#Write a menu driven program: on Account Details: Name,Account Number
#press 1:Display Record
#press 2:Add a New Account
#press 3:Update Account
#press 4:Delete Account
#press 5:Exit
n=int(input("enter no.of records:"))
bank=dict()
for i in range(n):
    name=input("enter name:")
    acc_num=int(input("enter account number:"))
    bank[name]=acc_num
print("press 1:Display Record")
print("press 2:Add a New Account")
print("press 3:Update Account")
print("press 4:Delete Account")
print("press 5:Exit")
while(input("do you want to continue[y/n]:")=='y'):
    choice=-1
    choice=int(input("enter your choice:"))
    if choice==1:
        print("Name\t\tAccount Number")
        for k in bank:
            print(k,"\t\t\t",bank[k])
    elif choice==2:
        print("enter the details to add new account:")
        name=input("enter name:")
        acc_num=int(input("enter account number:"))
        bank[name]=acc_num
        print("Account Added Successfully")
    elif choice==3:
        print("enter the details to update account:")
        name=input("enter name to be updated:")
        acc_num=int(input("enter account number:"))
        bank.update({name:acc_num})
        print("Account Updated Successfully")
    elif choice==4:
        print("enter the details to delete account:")
        name=input("enter name to be deleted:")
        bank.pop(name)
        print("Account Deleted Successfully")
    elif choice==5:
        quit()
    else:
        print("enter correct choice")
else:
    quit()

    

      

    
    
