list1=[]
n=int(input("enter value for n:"))
print("enter elements:")
for i in range(1,n+1):
    list1.append(int(input()))
print(list1)    
