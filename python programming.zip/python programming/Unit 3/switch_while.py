n=int(input("enter value for n:"))
a=[]
for i in range(n):
    a.append(int(input()))
print(a)
while(input("do you really want to continue[y\n]")=='y'):
    choice=-1
    choice=int(input("enter your choice:"))
    if choice==1:
        p=int(input("enter element to be inserted:"))
        a.append(p)
        print(a)
    elif choice==2:
        q=int(input("enter element to be removed:"))
        a.remove(q)
        print(a)
    elif choice==3:
        print(a)
    else:
        print("enter correct choice")
else:
    exit()
