#Mapping Datatype : dictonary
#It is a mapping between a set of keys and a set of values.
#{}, dict()
d1 = {}
d2 = dict()
print(d1)
print(d2)
#Dictionaries are used to store data values in key:value pairs.
'''A dictionary is a collection which is ordered*,
changeable and do not allow duplicates'''
#Example:
d = {
    'name': 'vijay kumar',
    'rollno':1234,
    'marks':93.5
    }
print(d)
print(type(d))

#Changable
d['marks'] = 99.1
print(d)
#do not allow duplicates
d = {
    'name': 'vijay kumar',
    'rollno':1234,
    'marks':93.5,
    'marks':99.5
    }
print(d)

#Accessing the elements of dictonary : 
print(d['name'])
#get()
print(d.get('name'))

#Operations
#length: len()
print(len(d))
#keys()
print(d.keys())
#values()
print(d.values())
#items()
print(d.items())


#update()
d.update({'marks':95.1})
print(d)

#Adding an item: directly with adding key, update()
d['branch'] = "CSE"
print(d)
d.update({'university':"sru",'grade':'A'})
print(d)

#Removing Items: pop('key'), popitem(),del keyword
d.pop('grade')
print(d)

d.popitem()
print(d)

del d['branch']
print(d)

#Deleting entire dictonary variable: del keyword,
#clear(): helps to clear the items in dictonary
'''del d
print(d)

d.clear()
print(d)'''

#copy()
d1 = d.copy()
print(d1)

d2 = dict(d1)
print(d2)

#loop through a dictonary
for i in d:
    print(i)
#keys
for k in d.keys():
    print(k)

#values:
for i in d:
    print(d[i])
for v in d.values():
    print(v)
#items:
for x,y in d.items():
    print(x,y)

#Nested Dictonary:
sru = {
    'college1':{
        'name': 'srec',
        'year':2002
        },
    'college2':{
        'name': 'srit',
        'year':2009
        },
    'college3':{
        'name': 'sriit',
        'year':2011
        }
    }
print(sru)

#Example 2:
college1={
            'name': 'srec',
            'year':2002
        }
college2={
            'name': 'srit',
            'year':2009
        }
college3={
            'name': 'sriit',
            'year':2011
        }
sru = {
           'col1':college1,
           'col2':college2,
           'col3':college3
       }
print(sru)

'''1.write a program to enter names of employees and
their salaries as input and store them in a dictionary.
Here n is to input by the user. 
emp = dict()
n = int(input("Enter number of employess:"))
for i in range(n):
    name = input("Enter name of Employee:")
    salary = int(input("Enter salary"))
    emp[name] = salary
print("\n Employee Name \t Salary")
for k in emp:
    print(k,'\t',emp[k])

2.	Write a program to count the number of times
a character appears in a given string. 
st = input("Enter a String")
d = dict()
for ch in st:
    if ch in d:
        d[ch] = d[ch]+1
    else:
        d[ch] = 1
for k in d:
    print(k,":",d[k])

3. Write a program to convert a number entered by the user into
its corresponding number in words.for example if the input is 876
then the output should be ‘Eight Seven Six’.
n = input("Enter a number")
num_word = {0:'Zero',1:'One',2:'Two',3:'Three',4:'Four',5:'Five',6:'Six',7:'Seven',8:'Eight',9:'Nine'}
result = ' '
for i in n:
    key = int(i)
    value = num_word[key]
    result = result+' '+value
print("The Given Number is:",n)
print("The Given Number in Words:",result)'''

'''4. Menu Driven Program: on Account Details : Name, A/c Number
press 1 : Display record
press 2 : Add a new Account
press 3 : Update Account
press 4 : Delete Account
press 5 : exit'''

n = int(input("Enter number of records:"))
d = dict()
for i in range(n):
    name = input("Enter Name:")
    acc_num = int(input("Enter 10 digit A/C Number:"))
    d[name] = acc_num
while(input("Do you really want to continue[y/n]:") == 'y'):
    choice = -1
    choice = int(input("Enter Your Choice:"))
    if choice == 1:
        print("Name \t \t \t A/C Number")
        for k in d:
            print(k,"\t \t \t", d[k])
    elif choice == 2:
        name = input("Enter Name:")
        acc_num = int(input("Enter 10 digit A/C Number:"))
        d[name] = acc_num
        print("Account added Sucessfully")
    elif choice == 3:
        name = input("Enter Name to be updated:")
        acc_num = int(input("Enter 10 digit A/C Number to be updated:"))
        d[name] = acc_num
        print("Account Updated Sucessfully")
    elif choice == 4:
        name = input("Enter Name to deleted:")
        d.pop(name)         #del d[name]
        print("Account Deleted Sucessfully")
    elif choice == 5:
        quit()
    else:
        print("Enter Correct Choice")

else:
    exit()






































