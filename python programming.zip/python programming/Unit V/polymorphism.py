#polymorphism
#Method Overloading:
class Moverload:
    def add(self,a=None,b=None):
        print(a,b)
obj=Moverload()
obj.add()
obj.add(10)
obj.add(10,20)
#overriding:inheritance
class parent:
    def mobile(self):
        print("Nokia")
class child:
    def mobile(self):
        print("Blackberry")
c1=child()
c1.mobile()
