#Python Graphical User Interface : tkinter,wxpython,javapython
#Creation of Window:
'''from tkinter import *
window = Tk()
window.title("S R University")
window.geometry("400x300")
window.mainloop()

#Create a Label:Label()
from tkinter import *
window = Tk()
window.title("Creation of Label")
lb1 = Label(window,text = "Enter Name:")
lb1.place(x=30,y=40)
window.geometry("400x300")
window.mainloop()

#Button: Button()
from tkinter import *
window = Tk()
window.title("Creation of Button")
btn1 = Button(window,text="Click Here")
btn1.place(x=40,y=60)
window.geometry("400x300")
window.mainloop()

#Entry Widgets: Entry()
from tkinter import *
window = Tk()
window.title("Creation of Text Box")
lb1 = Label(window,text = "Enter Name:")
lb1.place(x=30,y=40)
txt1 = Entry(window,text="txt1",bd=5)
txt1.place(x=120,y=40)
lb2 = Label(window,text = "Enter Rollno:")
lb2.place(x=30,y=80)
txt2 = Entry(window,text="txt2",bd=5)
txt2.place(x=120,y=80)
btn1 = Button(window,text="Click Here")
btn1.place(x=80,y=150)
window.geometry("400x300")
window.mainloop()'''

#Selection Widgets:
'''Radiobutton, Checkbutton,Combobox,Listbox'''
from tkinter import *
from tkinter.ttk import *
window = Tk()
window.title("Selection Widgets")

lb1=Label(window,text="Enter Name:")
lb1.grid(row=0,column=0)
txt1=Entry(window,text="txt1")
txt1.grid(row=0,column=1)
lb2=Label(window,text="Enter Rollno:")
lb2.grid(row=1,column=0)
txt2=Entry(window,text="txt2")
txt2.grid(row=1,column=1)
#Combobox : Dropdownlist
lb3=Label(window,text="Select Branch:")
lb3.place(x=5,y=50)
var = StringVar()
var.set("CSE")
data = ("CSE","ECE","EEE","ME")
cb = Combobox(window,values=data)
cb.place(x=100,y=50)

#Listbox
lb4=Label(window,text="Select Subject:")
lb4.place(x=5,y=100)
lb = Listbox(window,height=5,selectmode='multiple')
data1=("APTT","PSPW","ENG","MAT")
for num in data1:
    lb.insert(END,num)
lb.place(x=100,y=100)

#Radiobutton: Radiobutton()
lb5=Label(window,text="Select Gender:")
lb5.place(x=5,y=180)
v0 = IntVar()
v0.set(1)
r1 = Radiobutton(window,text="Male", variable=v0,value=1)
r1.place(x=100,y=180)
r2 = Radiobutton(window,text="Female", variable=v0,value=2)
r2.place(x=200,y=180)

#Checkbutton
lb6=Label(window,text="Select Hobbies:")
lb6.place(x=5,y=200)
v1 = IntVar()
v2 = IntVar()
chk1 = Checkbutton(window,text="Cricket",variable=v1)
chk1.place(x=100,y=200)
chk2 = Checkbutton(window,text="Tennis",variable=v2)
chk2.place(x=200,y=200)

btn1 = Button(window,text="Click Here")
btn1.place(x=150,y=220)
window.geometry("400x300")
window.mainloop()










