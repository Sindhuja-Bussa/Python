#Event Handling:
from tkinter import *
from tkinter.ttk import *
from tkinter.messagebox import *
window = Tk()
window.title("Event Handling")
def hello():
    n1 = txt1.get()
    showinfo("Hello:",n1)
lb1 = Label(window,text="Enter Name:")
lb1.grid(row=0,column=0)
txt1 = Entry(window,text="txt1")
txt1.grid(row=0,column=1)
btn1 = Button(window,text="Click Here",command=hello)
btn1.grid(row=1,column=1)
window.geometry("400x300")
window.mainloop()
