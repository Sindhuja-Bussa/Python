#High Order Functions
#Lambda Function:anonymous function
'''lambda arguments:expression'''
#1
x=lambda a:a*10
print(x(5))
