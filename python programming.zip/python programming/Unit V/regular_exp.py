#Regular Expressions: Patterns
#find out
import re
txt="Welcome to SR University"
x=re.findall("SR",txt)
print(x)
#search()
import re
txt="Welcome to SR University"
x=re.search("SR",txt)
if x:
    print("found")
else:
    print("not found")
#split()
import re
txt="Welcome to SR University"
x=re.split("\s",txt)
print(x)
x=re.split("\s",txt,2)
print(x)
#sub()
import re
txt="Welcome to SR University"
x=re.sub("\s","9",txt)
print(x)
x=re.sub("\s","9",txt,2)
print(x)
