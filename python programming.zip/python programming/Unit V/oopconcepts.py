#OOPC  - Object Oriented Concepts in Python
'''
class
object
abstraction
Encapsulation
inheritance
polymorphism
'''
#class: class is a blue print, which is followed by object
#Class is Logical Structure with behavior
#Example: class class_name:
'''class student:
    rollno = 1234
    name = "sru"
    branch = "cse"
print("rollno:",rollno)'''

#Object: instance of a class is called object
#creation of object : object_variable = class_name()
#Example:
'''class student:
    rollno = 1234
    name = "sru"
    branch = "cse"
    def read(self):
        print("Reading")
        print("Instance Object:",self.rollno)
    def write(self):
        print("Writing")
#creation of object:
s1 = student()
print("rollno:",s1.rollno)
print("name:",s1.name)
print("branch:",s1.branch)
s1.read()
s1.write()'''

#Inheritance:
#Acquring the properties of parent class/base class to child class / Derived class
#types of Inheritance: 4 types
'''Single Inheritance
Multi-Level Inheritance
Hierarchical Inheritance
Multiple Inheritance
'''
#single Inheritance: parent to child
'''class parent:
    def p_display(self):
        print("Parent Class")
class child(parent):
    def c_display(self):
        print("Child Class")
c1 = child()
c1.p_display()
c1.c_display()

#Multi-level Inheritance:
class grandparent:
    def gp_display(self):
        print("Grand Parent Class")
class parent(grandparent):
    def p_display(self):
        print("Parent Class")
class child(parent):
    def c_display(self):
        print("Child Class")
c1 = child()
c1.gp_display()
c1.p_display()
c1.c_display()

#Hierarchical Inheritance: one parent two or more childs
class parent:
    def p_display(self):
        print("Parent Class")
class child1(parent):
    def c1_display(self):
        print("Child1 Class")
class child2(parent):
    def c2_display(self):
        print("Child2 Class")
#child1 Object Creation
c1 = child1()
c1.p_display()
c1.c1_display()
#child2 object Creation
c2 = child2()
c2.p_display()
c2.c2_display()

#Multiple Inheritance : Two Parents(Father,Mother)derives child class
class father:
    def f_display(self):
        print("Father Class")
class mother:
    def m_display(self):
        print("Mother Class")
class child(father,mother):
    def c_display(self):
        print("Child Class")
c1 = child()
c1.f_display()
c1.m_display()
c1.c_display()

#Encapsulation: wraping of data into single unit is called encapsulation
Access specifiers: public, private and protected
#public:
class encap:
    a = 10
    def display(self):
        print("Welcome to SRU")
obj = encap()
print(obj.a)
obj.display()

#Private : __a, __display()
class encap:
    __a=10 #private Variable
    def __display(self): #private method
        print("Welcome to SRU")
        print(self.__a)
obj = encap()
obj.display()'''
    
#polymorphism : Implementing same method in different context
#methods with same name implementing in different way
#Polymorphism is acheived by two ways Overloading, Overriding
#1. Overloading :
'''1. Operator Overloading : + - addition, + - Concatination
2. Method Overloading : add(), add(10,20)
#Example:Method Overloading
class moverload:
    def add(self,a=None,b=None):
        print(a,b)
obj = moverload()
obj.add()
obj.add(10)
obj.add(10,20)

#2. Overriding: can be implemented with inheritance
Method name should be same, number of arguments should be same
class father:
    def mobile(self):
        print("Father Mobile Nokia")
class child:
    def mobile(self):
        print("Child Mobile Iphone")
obj = father()
obj = child()
obj.mobile()'''
    
#Abstraction:
'''Hiding the Implementation details and
Showing the Essential details is called Abstraction
Example : apk files, exe files...'''
#abstract class, abstract method, concrete class
#abstract class :which have abstract methods
#abstract method : method with declaration with no defination
#concrete class : class without abstract methods

#import from module ABC,abstractmethod
from abc import ABC,abstractmethod
class AbstractDemo(ABC):
    @abstractmethod
    def display(self):
        None
    @abstractmethod
    def show(self):
        None
class Demo(AbstractDemo):
    def display(self):
        print("Abstract Method")
    def show(self):
        print("show Method")
class Demo1(AbstractDemo):
    def show(self):
        print("Show Method")
    def display(self):
        print("Display Method")
obj = Demo1()
obj.display()


        








