#Python Errors
#Syntax Error: which stops the execution of a program
a=10
if a>10:
    print(a)
else:
    print("error")
#Exception Error: are the ubnormal condition which stops the execution of a program
l=[1,2,3]
print("First Element",l[0])
#print("Fourth Element",l[3])
#Types of Errors
'''try:
#write the code/logic
except:
#handles exception'''
#1
try:
    l=[1,2,3]
    print("First Element",l[0])
    print("Fourth Element",l[3])
except:
    print("an exception has been occured")
#2
try:
    l=[1,2,3]
    a=int(input("enter value for a:"))
    b=int(input("enter value for b:"))
    c=a/b
    print("a/b=%d"%c)
except Exception as e:
    print(e)
    print("an error occured")
#else block: No exception, else will be executed
try:
#write the code/logic
'''except:
#handles exception
else:
#no exceptions'''
#1
try:
    print("hello")
except:
    print("An Error Occured")
else:
    print("No Exceptions")
#2
try:
    a=int(input("enter value for a:"))
    b=int(input("enter value for b:"))
    c=a/b
    print("a/b=%d"%c)
except Exception as e:
    print(e)
    print("an error occured")
else:
    print("No Exceptions")
#else block: No exception, else will be executed
'''try:
#write the code/logic
except:
#handles exception
finally:
#always executes'''
#1
try:
    a=int(input("enter value for a:"))
    b=int(input("enter value for b:"))
    c=a/b
    print("a/b=%d"%c)
except Exception as e:
    print(e)
    print("an error occured")
finally:
    print("Always Executes")
#Multiple Exceptions
try:
    a=int(input("enter value for a:"))
    b=int(input("enter value for b:"))
    d=a/c
    print("a/b=%d"%d)
except Exception as e:
    print(e)
    print("an error occured")
except Exception as e:
    print(e)
else:
    print("an error occured")
finally:
    print("Always Executes")
