#Python Graphical User Interface
#tkinter
#Creating Window
'''from tkinter import *
window=Tk()
window.title("SR UNIVERSITY")
window.geometry("300x200+10+10")
window.mainloop()'''
#label
'''from tkinter import *
window=Tk()
window.title("SR UNIVERSITY")
lb1=Label(window,text="Enter Name:")
lb1.place(x=30,y=40)
window.geometry("300x200+10+10")
window.mainloop()'''
from tkinter import *
'''window=Tk()
window.title("SR UNIVERSITY")
lb1=Label(window,text="Enter Name:")
lb1.place(x=30,y=40)
lb2=Label(window,text="Enter Rollno:")
lb2.place(x=30,y=80)
window.geometry("300x200+10+10")
window.mainloop()'''
#Button
'''from tkinter import *
window=Tk()
window.title("SR UNIVERSITY")
btn1=Button(window,text="Click Here")
btn1.place(x=40,y=50)
window.geometry("300x200+10+10")
window.mainloop()'''
#Entry Widgets
from tkinter import *
'''window=Tk()
window.title("SR UNIVERSITY")
txt1=Entry(window,text="txt1",bd=5)
txt1.place(x=40,y=40)
txt2=Entry(window,text="txt2",bd=5)
txt2.place(x=40,y=80)
window.geometry("300x200+10+10")
window.mainloop()'''
'''from tkinter import *
window=Tk()
window.title("SR UNIVERSITY")
lb1=Label(window,text="Enter Name       :")
lb1.place(x=30,y=40)
txt1=Entry(window,text="txt1",bd=5)
txt1.place(x=150,y=40)
lb2=Label(window,text="Enter Rollno     :")
lb2.place(x=30,y=80)
txt2=Entry(window,text="txt2",bd=5)
txt2.place(x=150,y=80)
btn1=Button(window,text="Click Here")
btn1.place(x=100,y=150)
window.geometry("300x200+10+10")
window.mainloop()'''
#selection widgets
from tkinter import *
from tkinter.ttk import Combobox
window=Tk()
window.title("SR UNIVERSITY")
#Combobox
var = StringVar()
var.set("cse")
data=("cse","ece","eee","me")
cb=Combobox(window,values=data)
cb.place(x=10,y=50)
window.geometry("300x200+10+10")
window.mainloop()
















