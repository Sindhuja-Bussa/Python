#Python File Handling:
#A File is a named location on disk to store related information
#Files are used to store data permanently in memory
#Files helps you to store the related information permanently in the memory
#with the help of files we can do the operations like
#open()
#read() and write() operations
#file close()
#open(): to read or write the data to the file we need to first open the file
#syntax: open("filename","modes")
#Example:
'''f = open("sru.txt","r")
#Types of files:two 1.text file - t,2. binary file- b (images)
by default f = open("sru.txt","rt") is text file
#modes: are of 4 types
 "r" - Read file,
"a" - append,
"w"-Write file,
"x" - Creates a new file
#read():we can read a file with function read()
f = open("sru.txt","r")
print(f.read())
f.close()
#read(value): reads no of characters based on value
f = open("sru.txt","r")
print(f.read(5))
f.close()
#readline() : read a line from the file
f = open("sru.txt","r")
print(f.readline())
print(f.readline())
f.close()
#loop
f = open("sru.txt","r")
for i in f:
    print(i)
f.close()

#write(): writing to an existing file
#'a' - append - add data to existing data
#'w' - write - overide the data,the content of your old data will errase

#'a' - append - add data to existing data
f = open("sru.txt",'a')
f.write("\n Hello iam adding an extra data to sru.txt file")
f.close()
#print the files data
f = open("sru.txt",'r')
print(f.read())
f.close()

#'w' - write - overwrite the data,the content of your old data will errase
f = open("sru.txt","w")
f.write("Iam overwrite the data,your old data will errase")
f.close()
#print the file
f = open("sru.txt","r")
print(f.read())
f.close()'''

#Creating a new file:
''''x' - creates a new file, if files exists you will get error
'w' - creates a file, if file not exists in specifed location will create a file
'a' - creates a file, if file not exists in specifed location will create a file
'''
'''#'x'
f = open("abc.txt",'x')
f.close()
#'w'
f = open("abc1.txt",'w')
f.close()
#'a'
f = open("abc2.txt",'a')
f.close()'''

#delete a file:
#To delete a file we need to import a module os(operating system)
#and use the function remove()
'''import os
os.remove("abc1.txt")
#check if file exists
import os
if os.path.exists("abc1.txt"):
    os.remove("abc1.txt")
else:
    print("File doesnot exists")'''

#deleting Folder: os.remdir(): if directory is empty only it will delete
'''import os
os.rmdir("abc")'''

#counting number of words,no of lines,no of characters
'''f = open("sample.txt","r")
nl = 0
nw = 0
nc = 0
for line in f:
    line = line.strip("\n")
    words = line.split()
    nl = nl+1
    nw = nw+len(words)
    nc = nc+len(line)
f.close()
print("lines:",nl,"words:",nw,"characters:",nc)'''

#write a python program to read and write binary file

'''f = open("binary1.bin",'wb')
l = [9,10,4,7]
b = bytearray(l)
f.write(b)
f.close()
f = open("binary1.bin",'rb')
print(f.read())
f.close()'''

#Write a menu driven program on files:
'''press 1. Create a file
press 2 . Write content to the file
press 3. add content to the file
press 4. display the content of the file
press 5. delete a file'''
print("press 1. Create a file")
print("press 2 . Write content to the file")
print("press 3. add content to the file")
print("press 4. display the content of the file")
print("press 5. delete a file")
while(input("do you continue[y/n]:")=='y'):
    choice = int(input("Enter Your Choice:"))
    if choice == 1:
        f = open("example.txt",'x')
        print("File Created Sucessfully")
    elif choice == 2:
        f = open("example.txt",'w')
        data = input("Enter Data:")
        f.write(data)
        f.close()
        print("Content Written sucessfully:")
    elif choice == 3:
        f = open("example.txt",'a')
        data = input("Enter Data to be Added:")
        f.write(data)
        f.close()
        print("Content Added sucessfully:")
    elif choice == 4:
        f = open("example.txt",'r')
        print(f.read())
        f.close()
    elif choice == 5:
        import os
        if os.path.exists("example.txt"):
            os.remove("example.txt")
            print("File Removed Sucessfully")
        else:
            print("File not found")
    else:
        print("Enter Correct Choice")
else:
    exit()














