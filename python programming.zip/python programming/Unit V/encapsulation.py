#polymorphism : Implementing same method in different context
#methods with same name implementing in different way
#Polymorphism is acheived by two ways Overloading, Overriding
#1. Overloading :
'''1. Operator Overloading : + - addition, + - Concatination
2. Method Overloading : add(), add(10,20)'''
#Example:Method Overloading
class load:
    def add(self,a=None,b=None):
        print(a,b)
m = load()
m.add()
m.add(10)
m.add(10,20)

#2. Overriding: can be implemented with inheritance
'''Method name should be same, number of arguments should be same'''
class father:
    def mobile(self):
        print("Father Mobile Nokia")
class child:
    def mobile(self):
        print("Child Mobile Iphone")
obj = father()
obj = child()
obj.mobile()                    

































