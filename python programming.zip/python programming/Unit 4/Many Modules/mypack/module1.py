#module1.py
def sru():
    print("Welcome to S R University")
def subject():
    print("Advanced Programming Tools and Techniques")
    
