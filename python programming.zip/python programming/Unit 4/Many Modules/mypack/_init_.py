#_init_.py
from .module1 import sru
from .module1 import subject
from .module2 import sum
