#module2.py
def sum(x,y):
    return x+y
