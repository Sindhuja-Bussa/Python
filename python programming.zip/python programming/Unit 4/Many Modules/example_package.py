from mypack import module1
from mypack import module2
module1.sru()
module1.subject()
r = module2.sum(2,5)
print(r)
