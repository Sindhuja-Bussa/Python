#Module: it is a file, with set of functions
#1.Buit in Module: math,random, 2. userdefined module
#user defined Module:
def college():
    print("Welcome to S R University")
def course(name):
    print("Welcome to "+name)
def add(x,y):
    print(x+y)
def sub(x,y):
    print(x-y)
