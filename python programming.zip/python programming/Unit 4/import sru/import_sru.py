import sru
sru.college()
sru.course("APTT")
sru.add(10,20)
sru.sub(30,20)
