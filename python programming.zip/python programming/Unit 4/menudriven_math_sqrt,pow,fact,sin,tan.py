import math
print("press 1:square root,ceil,floor,pow")
print("press 2:factorial")
print("press 3:sin")
print("press 4:tan")
print("press 3:exit")
def basic_operation():
    print(math.sqrt(16))
    print(math.ceil(2.5))
    print(math.floor(2.5))
    print(math.pow(2,5))
def fact():
    print(math.factorial(5))
def sin():
    print(math.sin(6))
def tan():
    print(math.tan(4))
while(input("do you want to continue:")=='y'):
    choice=-1
    choice=int(input("enter your choice:"))
    if choice==1:
        basic_operation()
    elif choice==2:
        fact()
    elif choice==3:
        sin()
    elif choice==4:
        tan()
    else:
        exit()
else:
    quit()
    
