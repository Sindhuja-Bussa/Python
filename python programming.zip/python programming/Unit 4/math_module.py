#Built in Module: math module
import math
print(math.ceil(2.5))
print(math.floor(2.5))
print(math.sqrt(16))
print(math.pow(2,5))
print(math.factorial(5))
print(math.gcd(15,5))
print(math.pi)
r=4
print("Area of circle:",math.pi*r*r)
#Logarithm Functions: log(2,3) , log2(),log10()
print(math.log(2,3))
print(math.log2(16))
print(math.log10(1000))
#Trignometric Functions
#degrees = 360, radians = 2pi
a = math.pi/6
b = 30
#converting radians to degrees: degrees()
print(math.degrees(a))

#converting degrees to radians : radians()
print(math.radians(b))
print(math.sin(30))
print(math.radians(30))
print(math.sin(math.radians(30)))
print(math.degrees(0.5235987755982988))

'''Write a menu driven program using functions:
press 1: square root, ceil,floor,pow
press 2: factorial
press 3: sin
press 4 : cos
press 5: tan
press 6: exit'''
def general_fun():
    print(math.sqrt(4))
    print(math.ceil(2.5))
    print(math.pow(2,5))
    print(math.floor(2.5))
def fact_fun():
    print(math.factorial(4))
def sin_fun():
    print(math.sin(math.radians(30)))
def cos_fun():
    print(math.cos(math.radians(30)))
def tan_fun():
    print(math.tan(math.radians(30)))

print("press 1: square root, ceil,floor,pow")
print("press 2: factorial")
print("press 3: sin")
print("press 4 : cos")
print("press 5: tan")
print("press 6: exit")    
while(input("do you continue[y/n]:")=='y'):
    choice = int(input("Enter Your choice:"))
    if choice == 1:
        general_fun()
    elif choice == 2:
        fact_fun()
    elif choice == 3:
        sin_fun()
    elif choice == 4:
        cos_fun()
    elif choice == 5:
        tan_fun()
    else:
        print("Enter Correct Choice:")
else:
    exit()                                                                              

