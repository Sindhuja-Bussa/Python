#Accessing Variable
import student_creation as s #alias
name = s.student1['name'],s.student2['name'],s.student3['name']
print(name)

for i in s.student1:
    print(i)
for i in s.student1.keys():
    print(i)   
for i in s.student1:
    print(s.student1[i])
for i in s.student1.values():
    print(i)
for i in s.student1.items():
    print(i)
