#Module variable
student1 = {
            'name':"Ram",
            'rollno':1234,
            'subject':'APTT'
       }
student2 = {
            'name':"Raheem",
            'rollno':5678,
            'subject':'SSD'
       }
student3 = {
            'name':"Robert",
            'rollno':4321,
            'subject':'PSWP'
       }
