#Write a python program to implement arithmetic operators using input and output functions.

# Arithmetic Operators :  '+,-,*,**,/,//,%'
print("Arithmetic Operators : ")
a=float(input("enter value for a:"))
b=float(input("enter value for b:"))
print("Addition:",a+b)
print("Subtraction:",a-b)
print("Multiplication:",a*b)
print("Division:",a/b)
print("Power:",a**b)
print("Floor Division:",a//b)
print("Modulo Division:",a%b)
