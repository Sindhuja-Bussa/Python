a=10
print(type(a))
print(id(a))
b=2.5
print(type(b))
print(id(b))
