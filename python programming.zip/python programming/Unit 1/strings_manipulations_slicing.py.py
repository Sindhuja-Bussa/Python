#write a python program to demonstrate the usage of string manipulations.

s = " S R University! "
print(s)
print(len(s))
print(s.upper())#To Convert into Uppercase
print(s.lower())#To Convert into lowercase
print(s.strip())

p = "Programming Tools and Techniques"
q = p.replace("Programming","Advanced Programming")
print(q)

print(s.split())
print(p.split())

s1 = "SR Enginnering College eshtablished in the year:{}"
year = 2002
print(s1.format(year))

s2 = "I Buy {} total cost {} each cost {} rs"
k=10
l=250
m="apples"
print(s2.format(m,l,k))
print(s2.format("apples",250,10))

a2 = "I Buy {2} total cost {1} each cost {0} rs"
k=10
l=250
m="apples"
print(a2.format(k,l,m))
print(a2.format(10,250,"apples"))

#write a python program to implement slicing strings.

#Slicing
str= "S R University!"
print(str)
print(len(str))
print(str[0:14])
print(str[0:13])
print(str[4:11])
print(str[-5:-2])
print(str[0:16:1])
print(str[::1])
print(str[::2])
print(str[::3])
print(str[2:8:3])
print(str[::-1])
print(str[::-2])





