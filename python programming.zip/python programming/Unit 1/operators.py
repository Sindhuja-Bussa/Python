#Operators in Python

#1. Arithmetic Operators :  '+,-,*,**,/,//,%'
print("Arithmetic Operators: ")
a=10
b=20
print("Addition:",a+b)
print("Subtraction:",a-b)
print("Multiplication:",a*b)
print("Division:",a/b)
print("Power:",a**b)
print("Floor Division:",a//b)
print("Modulo Division:",a%b)

#2.  Relational Operators: '<,>,<=,>=,==,!='
print("Relational Operators: ")
x=5
y=3
z=8
print("Less than:",x<y)
print("Greater than:",x>y)
print("Less than Equal to:",x<=y)
print("Greater than Equal to:",x>=y)
print("Equal to:",x==y)
print("Not Equal to:",x!=y)

#3. Assignment Operators: '+=,-=,*=,/='
print("Assignment Operators: ")
p=3
q=5
p+=q # p=p+q
print(p) # 6
p-=q #p=p-q, 6-4=2
print(p)
p*=q # p=p*q
print(p)
p/=q # p=p/q
print(p) 

# 4. Logical Operators: 'and,or,not'
print("Logical Operators:")
k=10
l=30
m=40
print((k<l) and (k>m))
print((k<l) or (k>m))
print(not((k<l) and (k>m)))
print(not((k<l) or (k>m)))

#5. Membership Operators: 'in,not in'
print("Membership Operators:")
list1=['1',2,3,'a',2.5]
print('2' in list1)
print('2' not in list1)
print('a' in list1)
print(a not in list1)
      
#6. Identity Operators: 'is,is not'
print("Identity Operators: ")
u=2
v=4
w=4
print(u is v)
print(u is not v)
print(v is w)
print(u is v)

# 7. Bitwise Operators: '&,|,~,^,>>,<<'
print("Bitwise Operators: ")
a=10 #00001010
b=5  #00000101
print(a&b)
print(a|b)
print(~(b))
print(~(a))
print(a^b)
print(a>>2)
print(b<<1)


