#Write a python program to calculate addition of two numbers of different datatypes using input and output functions.

#Addition of Two Numbers

a = int(input("enter value for a:"))
b= int(input("enter value for b:"))
c=a+b
print("addition: ",c)

#Addition of Two Strings

x= input("enter value for x:")
y= input("enter value for y:")
z=x+y
print("addition: ",z)

#Addition of Two Float Numbers

a = float(input("enter value for a:"))
b= float(input("enter value for b:"))
c=a+b
print("addition: ",c)



