#program to sort two numbers

a=10
b=20
(a,b)=(b,a)
print(a,b)
