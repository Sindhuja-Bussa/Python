#write a python program to implement type conversions.
#Implicit Type Conversion

print("Implicit Type Conversion")
a=10
print(type(a))
print(id(a))
b=2.5
print("addition:",a+b)#It is converting into float

#Explicit Type Conversion

print("Explicit Type Conversion")
x=4
print(type(x))
y=float(x)

#Weidining

print("Weidining")
print(y)
print(type(y))

#Narrowing

print("Narrowing")
k=2.5
print(type(k))
i=int(k)
print(i)
print(type(i))

#Invalid

'''m="hello"
print(m)
print(type(m))
m=int(m)'''#We cannot convert string to another datatype




