a=10
b=20
print("addition")
print(a+b)
print("subraction")
print(a-b)
print("multiplication")
print(a*b)
print("power")
print(a**b)
print("division")
print(a/b)
print("floor division")
print(a//b)
print("modulo division")
print(a%b)

