#Data types


#Numbers:Integers,Float,Complex
a=10
b=2.5
c='a+i'
print(a,b,c)

#Sequence - Strings,Lists,Tuple

#Strings
s1="S R University"
print(s1)
print(len(s1))
print(s1[10])

#Lists
list1=[1,2,3,'a','c',"sru",'a+i']
print(list1)
print(len(list1))
print(list1[4])
list1[3]='z'
print(list1)

#Tuple
tuple1=('a',1,2,2.5,'a+i')
print(tuple1)
print(len(tuple1))
print(tuple1[2])
#tuple1[0]='z'  In tuple values are inmutable, we cant change 'a' value to 'z'.
#print(tuple1) 


#sets
set1={'a',1,2.5,'x','i+j'}
print(set1)
print(len(set1))
#print(set1[1])   In sets values are inmutable no need to equate with x since there are no index positions



#mappings - dictionaries

student = {
    'Name':"Bussa Sindhuja",
    'Roll no':'2103A51085',
    'Department':'CSE'}
print(student)
print(len(student))
print(student['Name'])



