Python 3.10.4 (tags/v3.10.4:9d38120, Mar 23 2022, 23:13:41) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
a=10
b=20
a+b
30
a=10
b=20
a-b
-10
a=10
b=20
a*b
200
a=10
b=20
a**b
100000000000000000000
a=10
b=20
a/b
0.5
a=10
b=4
a//b
2
a=4
b=5
a%b
4

=============================================== RESTART: C:/Users/sindh/OneDrive/Desktop/python programming/code/arithmetic_operations.py ==============================================
addition
30
subraction
-10
multiplication
200
power
100000000000000000000
division
0.5
floor division
0
modulo division
10
'''swapping two numbers'''
'swapping two numbers'
a=10
b=20
(a,b)=(b,a)
a,b
(20, 10)
'''Location or address of a variable'''
'Location or address of a variable'
a=10
print(id(a))
1654999876112
'''type of variable'''
'type of variable'
print(type(a))
<class 'int'>
